
import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class bg extends JPanel{ 
        private Image image; 
        public bg() { 
            //menset transparansi background dengna menghilangkan opague 
            setOpaque(false); 
            //mengambil image pada posisi tertentu 
            image = new ImageIcon(getClass().getResource("gambar/images (4).jpg")).getImage(); 
        } 
     
        @Override 
        protected void paintComponent(Graphics g) { 
            super.paintComponent(g); 
            //melakukan penggambaran dengan memanfaatkan Graphics2D 
            Graphics2D gd = (Graphics2D) g.create(); 
            //mengatur nilai transparansi gambar antara 0.0 - 1.0 Float 
            gd.setComposite(AlphaComposite.SrcOver.derive(1.0F)); 
            //menggambar image 
            gd.drawImage(image, 0, 0, getWidth(), getHeight(), null); 
            //menutup Graphics2D 
            gd.dispose(); 
        } 
    }