import java.awt.*;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class txtf extends JTextField{

    public txtf() {
        super();
        setOpaque(false); setHorizontalAlignment(CENTER);
    }
    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
        super.paint(g2);
        g2.dispose();
    }

    
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();

        super.paintComponent(g);

        Color dark = new Color(0.5F, 0.5F, 0.5F, 0.5F);
        Color light = new Color(0.5F, 0.5F, 0.5F, 0.5F);
        GradientPaint paint = new GradientPaint(0, 0, light, 0, getHeight() / 2, dark);
        g2.setPaint(paint);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
        g2.setColor(Color.BLACK);
        g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, getHeight(), getHeight());

        g2.dispose();
    }

    public char getKeyChar() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setKeyChar(char toUpperCase) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}